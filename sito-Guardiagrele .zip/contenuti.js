/* Contenuti del sito su Guardiagrele.
   Modifica qui i testi: la pagina li legge e li mostra automaticamente. */
window.SITO = {
  titolo: "Guardiagrele",
  sottotitolo: "La «città di pietra» sulla terrazza d'Abruzzo",
  benvenuto:
    "Benvenuti a Guardiagrele, borgo medievale alle pendici della Majella: vicoli lastricati, antiche architetture e un panorama che arriva fino al mare Adriatico.",

  foto: {
    hero: {
      src: "IMG_1015.webp",
      alt: "Veduta aerea del borgo di Guardiagrele, con i tetti in coppi e la strada che si snoda sul crinale tra le colline",
      didascalia: "Il borgo visto dall'alto, sul crinale tra le colline"
    },
    vedere: {
      src: "IMG_1016.jpeg",
      alt: "Chiesa in pietra con torre campanaria, portico ad arcate e orologio, affacciata su una piazza al tramonto",
      didascalia: "Pietra chiara, portico ad arcate e campanile sulla piazza"
    },
    sapori: {
      src: "IMG_1018.jpeg",
      alt: "Dolci con tre punte spolverati di zucchero a velo, farciti di crema pasticcera, in pirottini bianchi e blu",
      didascalia: "Le Sise delle Monache, spolverate di zucchero a velo"
    }
  },

  introduzione: {
    titolo: "Il borgo in breve",
    testo:
      "Guardiagrele è un incantevole borgo medievale adagiato alle pendici della Majella, in provincia di Chieti, sede legale dell'omonimo Parco Nazionale e riconosciuto tra «I Borghi più belli d'Italia». Celebrato da Gabriele d'Annunzio nel Trionfo della Morte come «città di pietra» e noto come la «terrazza d'Abruzzo» per la sua straordinaria vista panoramica, che spazia dalle vette montane fino al mare Adriatico, il paese sorge a circa 576 metri d'altitudine. Rinomato in tutta la regione per la sua gloriosa tradizione artigianale (in particolare nella lavorazione del ferro battuto, del rame e dell'oreficeria), il borgo accoglie i visitatori tra antiche architetture conservate, vicoli lastricati e una natura incontaminata.",
    fatti: [
      { valore: "576 m", etichetta: "altitudine, circa" },
      { valore: "Majella", etichetta: "sede del Parco Nazionale" },
      { valore: "Borghi più belli", etichetta: "d'Italia" }
    ]
  },

  storia: {
    titolo: "Storia",
    intro: "Una linea del tempo per scoprire come è nato e cresciuto il borgo.",
    tappe: [
      {
        quando: "Fine XII – inizio XIII secolo",
        titolo: "I Benedettini e la prima chiesa",
        testo:
          "Colonizzato in epoca medievale dai Benedettini, che vi eressero un monastero, il borgo vede sorgere la prima chiesa di Santa Maria come cappella cimiteriale fuori dalla prima cinta muraria, avviando l'espansione urbanistica guidata dai conti di Manoppello."
      },
      {
        quando: "1276 (o XIV secolo)",
        titolo: "I Francescani e San Francesco",
        testo:
          "Viene eretta dai Francescani la Chiesa di San Francesco (poi Santuario di San Nicola Greco) sulle fondamenta della chiesetta di San Siro."
      },
      {
        quando: "1338 (o metà del XIV secolo)",
        titolo: "Le reliquie di San Nicola Greco",
        testo:
          "Le sacre reliquie di San Nicola Greco, monaco basiliano, vengono traslate a Guardiagrele per volontà del signore Napoleone I Orsini e collocate nella Chiesa di San Francesco, sancendone il culto come compatrono cittadino."
      },
      {
        quando: "Anni '30 del XV secolo",
        titolo: "Nicola da Guardiagrele",
        testo:
          "Il celebre maestro orafo e scultore locale Nicola da Guardiagrele realizza il portale ogivale del Duomo con la lunetta dell'Incoronazione della Vergine e la preziosa croce processionale d'argento."
      },
      {
        quando: "1706",
        titolo: "La ristrutturazione barocca",
        testo:
          "A seguito di un drastico intervento edilizio (e dopo i danni di un terremoto), l'aspetto della Collegiata di Santa Maria Maggiore viene ristrutturato con la sopraelevazione al primo piano della navata in stile barocco e la costruzione della chiesa di San Rocco sul retro."
      },
      {
        quando: "1987",
        titolo: "Nasce il Museo del Duomo",
        testo:
          "Nell'originaria aula al piano terra del Duomo viene allestito il Museo del Duomo, per custodire i corali miniati, le sculture e i tesori sacri scampati ai bombardamenti della Seconda guerra mondiale e ai furti."
      }
    ]
  },

  fortezza: {
    titolo: "La Fortezza",
    testo:
      "Guardiagrele racchiude la sua memoria difensiva nell'impianto urbano medievale, scandito da una prima cinta muraria, antiche porte d'accesso e torri millenarie. Oggi i visitatori possono ripercorrere questa eredità difensiva passeggiando tra i vicoli del centro storico e ammirando le strutture fortificate inglobate nel tessuto cittadino.",
    elementi: ["Prima cinta muraria", "Antiche porte d'accesso", "Torri millenarie"],
    nota:
      "Per orari di apertura aggiornati e tariffe dei biglietti, consulta il sito ufficiale della Fortezza e del Comune di Guardiagrele."
  },

  vedere: {
    titolo: "Cosa vedere nel borgo",
    luoghi: [
      {
        nome: "Collegiata di Santa Maria Maggiore (Duomo)",
        testo:
          "Costruita interamente in pietra della Majella, sfoggia un elegante portale gotico del XV secolo e il monumentale affresco esterno di San Cristoforo, realizzato nel 1473 da Andrea Delitio."
      },
      {
        nome: "Chiesa di San Francesco e Santuario di San Nicola Greco",
        testo:
          "Edificio d'impianto duecentesco che custodisce al suo interno un prezioso sarcofago trecentesco in marmo rosso con l'urna-reliquiario del compatrono San Nicola Greco."
      },
      {
        nome: "Museo del Duomo",
        testo:
          "Allestito nell'antica aula al piano terra della Cattedrale, espone il gruppo scultoreo dell'Incoronazione della Vergine, i frammenti della croce d'argento di Nicola da Guardiagrele e preziosi corali miniati."
      },
      {
        nome: "Museo del Costume e delle Tradizioni della Nostra Gente",
        testo:
          "Situato nell'ex convento francescano (oggi sede anche del Municipio), raccoglie testimonianze etno-antropologiche, abiti d'epoca e utensili della cultura contadina locale."
      }
    ]
  },

  sapori: {
    titolo: "Sapori",
    piatti: [
      {
        nome: "Le Sise delle Monache (o Sise de Mòneche)",
        testo:
          "Dolce simbolo di Guardiagrele, composto da due strati di soffice pan di spagna farciti con crema pasticcera e caratterizzato da tre protuberanze spolverate di zucchero a velo.",
        simbolo: true
      },
      {
        nome: "Porchetta",
        testo:
          "Maialino arrostito al forno o allo spiedo e insaporito con pepe, rosmarino e aglio, piatto immancabile durante le festività estive."
      },
      {
        nome: "Pasticceria e dolci della tradizione",
        testo: "Amaretti, marzapane e caratteristici torroni artigianali."
      }
    ]
  },

  eventi: {
    titolo: "Eventi",
    elenco: [
      {
        quando: "6–8 agosto",
        nome: "Festa dei Santi Patroni Donato ed Emidio",
        testo:
          "Festività annuale durante la quale la statua di San Donato viene portata in processione per le vie del borgo, accompagnata dalla tradizione gastronomica della porchetta."
      },
      {
        quando: "Terza domenica di maggio",
        nome: "Festa di San Nicola Greco",
        testo: "Ricorrenza annuale in onore del monaco basiliano e compatrono cittadino."
      },
      {
        quando: "Ogni anno",
        nome: "Mostra dell'Artigianato Artistico Abruzzese",
        testo:
          "Esposizione annuale organizzata dall'omonimo Ente (con sede in Via Roma) per valorizzare le produzioni regionali in ferro battuto, ceramica, oreficeria, pietra e legno."
      }
    ]
  },

  faq: {
    titolo: "Domande frequenti",
    domande: [
      {
        d: "Per quale motivo Guardiagrele è soprannominata la «città di pietra» e la «terrazza d'Abruzzo»?",
        r: "Fu il poeta Gabriele d'Annunzio a definirla «città di pietra» per le sue architetture in pietra della Majella e «terrazza d'Abruzzo» per lo straordinario panorama che spazia dalla montagna fino al mare Adriatico."
      },
      {
        d: "Qual è il dolce tipico di Guardiagrele e dove si può degustare?",
        r: "Il dolce più celebre è rappresentato dalle «Sise delle Monache», soffici pan di spagna a tre punte farciti con crema pasticcera e ricoperti di zucchero a velo, acquistabili presso la storica pasticceria Emo Lullo nel centro cittadino."
      },
      {
        d: "Quali sono le principali tradizioni artigianali del borgo?",
        r: "Guardiagrele è considerata la capitale abruzzese del ferro battuto e vanta un'antica maestria nell'arte orafa, nella lavorazione del rame, della ceramica e della pietra lavorata."
      },
      {
        d: "Quali escursioni naturalistiche si possono intraprendere partendo da Guardiagrele?",
        r: "In quanto sede del Parco Nazionale della Majella, dal borgo si raggiungono facilmente la valle della Vesola a Bocca di Valle, la Cascata San Giovanni, la pineta di Piana delle Mele e i sentieri verso il Monte Amaro."
      },
      {
        d: "Dove posso verificare gli orari di apertura e i biglietti per visitare la Fortezza e le attrazioni della città?",
        r: "Per consultare gli orari di apertura aggiornati e le tariffe dei biglietti d'ingresso, si rimanda direttamente al sito ufficiale della Fortezza e del Comune di Guardiagrele."
      }
    ]
  }
};
